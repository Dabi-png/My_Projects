import { useState } from 'react';
import ProductInfo from './ProductInfo';

function Products() {
    const [products, setProducts] = useState([
        { id: 1, name: 'Product 1', price: 100 },
        { id: 2, name: 'Product 2', price: 200 },
        { id: 3, name: 'Product 3', price: 300 },
    ]);

    const deleteProduct = (id) => {
        setProducts(products.filter((product) => product.id !== id));
    };

    return (
        <div>
            <h2>Product List</h2>
            {products.map((product) => (
                <ProductInfo key={product.id} data={product} onDelete={deleteProduct} />
            ))}
        </div>
    );
};

export default Products;
