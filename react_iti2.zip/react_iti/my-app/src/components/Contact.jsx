function Contact() {
  return (
    <div>
      <h2>Contact Component</h2>
    </div>
  );
}

export default Contact;
