import Products from "./state+props/products";
import './App.css'
function App() {
  return (
    <div>
      <h1>App Page</h1>
      <Products />
    </div>
  );
}

export default App;