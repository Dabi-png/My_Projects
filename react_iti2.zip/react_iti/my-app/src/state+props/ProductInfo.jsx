function ProductInfo({ data, onDelete }) {
  return (
    <div style={{ margin: "10px", border: "1px solid gray", padding: "10px" }}>
      <p><strong>{data.name}</strong></p>
      <p>Price: {data.price} EGP</p>
      <button onClick={() => onDelete(data.id)}>Delete</button>
    </div>
  );
}

export default ProductInfo;